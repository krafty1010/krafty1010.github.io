# AWS samples

## EC2 
Deploy simple EC2 and illustate use of locals and conditions

## EKS
Deploy EKS using terraform AWS modules

## VPC
This module creates a VPC with private subnets, an internet gateway, and a NAT gateway to allow private instances to access the internet if needed. 

