# verifaro

Paul Grimwood p@krafty.space Jan 2025

## Section 1/A

"Create a Terraform configuration to deploy an EKS cluster into AWS. This should be in a new
VPC and include all other necessary resources. The new cluster should be designed to run up
to 250 pods, handle a total peak memory usage of 28GB per node and be resilient to the
failure of a single availability zone. The administrator should be able to use AWS services to
monitor metrics and view the logs of both the cluster and applications running in it".

### Solution explained

Sourced Terraform community module for EKS (with some customisations already added for a different project). This was configued this to create a manageed nodegroup spanning 3 AZs for required resiliency.
https://registry.terraform.io/modules/terraform-aws-modules/eks/aws/20.8.5

To handle 250 pods, referred to instance sizing https://github.com/aws/amazon-vpc-cni-k8s/blob/master/misc/eni-max-pods.txt

5.2xlarge  supports 58 ENIs  - hence 5 nodes required before allowing for pod resource utilisation.

To check actual capacity in real-world scenerio

```
kubectl get nodes -o json | jq '.items[].status.capacity.pods'
```

Note, details on pod resources were not provided hence only ENI used for sizing  

Selected m5.2xlarge instance type with 32Gb per node - exceeding the 28GB requirement.

Logging for cluster is provided by cloudwatch.tf. Logging for application is provided by mainfests/fluentd.yaml

In a production environment, the deployment would typically include a Horizontal Pod Autoscaler (HPA) and the EKS Cluster Autoscaler to enhance resilience against node and availability zone failures. However, these components have been omitted from this solution - they were not explicitly required in the technical test, and the necessary details about the application deployment were not provided.

#### Build instructions

```
cd aws/

terraform init

terraform plan --var-file=./dev/dev.tfvars

aws eks update-kubeconfig --region eu-west-1 --name <cluster name from output>

kubectl apply -f ../manifests/fluentd.yaml
```

## Section 1/B
"Add an OpsUser IAM role, granting it view only permissions to everything within the ops K8s
namespace. The user arn:aws:iam::1234566789001:user/ops-alice will be using the role from
the IP 52.94.236.248"

Terraform will create IAM role, policy etc usign IAM module. K8S RBAC configued by apply ./manifest/rbac.yaml

## Section 1/C
Add components so that pods using the order-processor K8s service account get credentials
injected granting them permissions to enumerate and read objects from the incoming-
orders S3 bucket.

This requires setting up IAM roles for service accounts per  - https://docs.aws.amazon.com/eks/latest/userguide/enable-iam-roles-for-service-accounts.html

* create OIDC

```eksctl utils associate-iam-oidc-provider --cluster $cluster_name --approve```

* Create IAM role and policy using terrafom iam modules ./aws/modules/iam

* create K8S SA using ./manifests/sa.yaml

* Deploy using terraform and kubectl as per section 1a

### Notes:
• Supply one zip file containing a single git repository containing everything.
• The answer to each question should be on its own branch.
• Add notes/explanations as comments and/or in separate files.


## Section 2/A
Explain what your approach / thought process would be in relation to the following scenarios:
You receive a security alert through Guard Duty noting suspicious outbound traﬃc to a
strange IP from an EC2 instance in the dev environment. What would be your approach to
investigating this potential risk?

The GuardDuty alert will include the AWS instance-id. Depending on the security posture it may be necessary to immediately snapshot the instance EBS volume (for later investigation) and then terminate the instance. Or to at least isolate the instance by restricting secuity group access

AWS cloudtrail can be used to investigate API calls originating from the instance

The existing instance, or a new instance launched from the snapshot can be accessed using SSM session manager or AWS console. Netstat can be used to identify which process is attempting to connect to the suspicious IP e.g. ```sudo netstat -tnp | grep <IP_ADDRESS>``` other tools such as lsof would be useful in the investigation as well as any logfiles


## Section 2/B
Company suﬀers a security incident in AWS which is now contained, Interviewee is tasked
with assisting the security lead with the investigation into what happened. As the cloud
expert, what would you recommend be the first action to start triaging the event?

First task would be to review cloudtrail logs to investigate API calls and identify potentially compromised resources (e.g instances as in previous example) or IAM principals.

This scenario demonstrated the importance of centralising logs in a secure log aggregation account and forward to an external log archival system to preserve log integrity.

Additionally, for both section 2 scenarious VPC flow logs may be available to provide further info.

Notes:
• Feel free to make some assumptions (but state them) if something is unclear

